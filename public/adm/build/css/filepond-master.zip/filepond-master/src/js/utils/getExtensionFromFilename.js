export const getExtensionFromFilename = name => name.split('.').pop();
