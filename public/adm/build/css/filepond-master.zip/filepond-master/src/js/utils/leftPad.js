export const leftPad = (value, padding = '') =>
    (padding + value).slice(-padding.length);
