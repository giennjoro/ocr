export const trim = str => str.trim();
